import type { Metadata } from 'next';
import { Geist, Geist_Mono } from 'next/font/google';
import './globals.css';

const geistSans = Geist({
  variable: '--font-geist-sans',
  subsets: ['latin'],
});

const geistMono = Geist_Mono({
  variable: '--font-geist-mono',
  subsets: ['latin'],
});

export const metadata: Metadata = {
  metadataBase: new URL('https://zrkk-1m-game.ardent-hawk-6772.chatgpt.site'),
  title: 'ZRKK 1M GAME',
  description: 'Real-time KPI and revenue dashboard for the ZRKK team.',
  openGraph: {title:'ZRKK 1M GAME',description:'Performance & Revenue Command Center',images:['/og.png']},
  twitter: {card:'summary_large_image',title:'ZRKK 1M GAME',description:'Performance & Revenue Command Center',images:['/og.png']},
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="th">
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased`}
      >
        {children}
      </body>
    </html>
  );
}

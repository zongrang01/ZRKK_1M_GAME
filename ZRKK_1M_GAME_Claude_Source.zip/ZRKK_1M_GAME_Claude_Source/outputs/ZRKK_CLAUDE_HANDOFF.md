# ZRKK 1M GAME — Claude handoff

## Goal

Continue development of the ZRKK real-time KPI, revenue mission, and team performance web app.

Live reference: https://zrkk-1m-game.haoabout.chatgpt.site/

## Stack

- TypeScript, React 19, Vinext/Vite
- Cloudflare Workers runtime
- Cloudflare D1 for persistent app state
- Drizzle schema/migration files

## Run locally

```bash
pnpm install
pnpm dev
```

Validation:

```bash
pnpm exec tsc --noEmit
node scripts/check-game.cjs
pnpm build
```

## Important files

- `app/dashboard-app.tsx` — main dashboard, missions, players, and autosave UI
- `app/game-details.tsx` — per-player KPI form
- `app/game-rules.ts` — role KPI templates and score calculations
- `app/access.ts` — manager/employee access rules
- `app/api/state/route.ts` — D1 state API and server-side write restrictions
- `app/api/me/route.ts` — current authenticated user access
- `app/staff-roster.ts` — default staff/role assignments
- `app/globals.css` — responsive UI
- `db/schema.ts`, `drizzle/` — database schema and migration

## Current access behavior

- Management roles: Branding & Marketing Strategy, Head of Marketing, and Sales Manager.
- The owner account also has management access.
- Managers can configure KPI details and employee records.
- Employees can update only Actual and Notes/evidence for the player record linked to their login email.
- The server revalidates employee writes; this is not only a UI lock.
- Live Site viewers/editors are managed by ChatGPT Sites and are not stored in this source archive.

## Current product features

- Eight equal-level organizational functions with cross-functional collaboration
- THB 1,000,000 monthly company target and carry-forward shortfall
- 100-point KPI scorecard and role templates
- Five gamification levels and personal-best growth tracking
- Team revenue levels
- Revenue missions, customer names, in-charge, and team members
- Branding Consultant prospect funnel
- Existing-customer follow-up tracking
- Real-time shared state through D1

## Deployment note

This archive does not contain live database contents, credentials, or a reusable deployment token. Claude can edit the code and return a patch or updated archive. The Site owner must publish the approved changes back to the existing ChatGPT Site.


## Update 2026-10-02 — Mobile app (PWA)

The app was made installable on phones as a PWA. Details in `outputs/ZRKK_MOBILE_APP_PWA.md`.

- Added: `public/manifest.webmanifest`, `public/sw.js`, `public/offline.html`, app icons in `public/`, `app/pwa-register.tsx`
- Edited: `app/layout.tsx` (manifest/appleWebApp/icons metadata + `viewport` export), `app/globals.css` (safe-area for standalone mode)
- **Not yet built or tested** — the previous machine had no Node.js. Next step: run the validation commands above, fix any build errors (e.g. if vinext does not support the `viewport` export, move those values into `<meta>` tags), then test install on iPhone Safari and Android Chrome.
- Optional future step: wrap in Capacitor for App Store / Play Store (needs full Xcode / Android Studio).
